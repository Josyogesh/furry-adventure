﻿/// <reference path="../Resources/Scripts/angular.min.js" />
/// <reference path="homeController.js" />
/// <reference path="trackerController.js" />
/// <reference path="reportController.js" />
/// <reference path="contactController.js" />

mainApp.controller('mainController', function ($scope) {
    $scope.message = "This page will be used to display mainController";
});

mainApp.directive('dropdownCustom', function () {
    return {
        restrict: 'E',
        scope: {
            array: '='
        },
        template: '<label>{{label}}</label>' +
                    '<select ng-model="ngModel" ng-options="a[optValue] as a[optDescription] for a in array">' +
						'<option style="display: none" value="">-- {{title}} --</option>' +
					'</select>',
        link: function (scope, element, attrs) {
            scope.label = attrs.label;
            scope.title = attrs.title;
            scope.optValue = attrs.optValue;
            scope.optDescription = attrs.optDescription;
        }
    };
});


