﻿mainApp.controller('reportController', function ($scope) {
    $scope.message = "This page will be used to display reportController";
});