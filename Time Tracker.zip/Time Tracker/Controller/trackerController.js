﻿/// <reference path="../Resources/Scripts/jquery-3.1.0.min.js" />
/// <reference path="../Resources/Scripts/angular.min.js" />

var scope;
mainApp.controller('trackerController', function ($scope) {
    $scope.message = "Please enter your efforts for this week";

    $scope.Resources = [
    { Id: 1, Name: "Yogesh" },
    { Id: 2, Name: "Gopi" },
    { Id: 3, Name: "Venkat" },
    { Id: 3, Name: "Vivek" },
    { Id: 3, Name: "Veda" }
    ];

    $scope.Applications = [
        { Id: 1, Name: "IRP" },
        { Id: 2, Name: "TET" },
        { Id: 3, Name: "ISAS" },
        { Id: 4, Name: "STAR" },
        { Id: 5, Name: "ICOP" },
        { Id: 6, Name: "SAM" }
    ];

    $scope.TaskTypes = [
        { Id: 1, Name: "Enhancement" },
        { Id: 2, Name: "Testing" },
        { Id: 3, Name: "Deployment" },
        { Id: 4, Name: "Development" }
    ];

    $scope.Phases = [
        { Id: 1, Name: "Analysis" },
        { Id: 2, Name: "Code" },
        { Id: 3, Name: "Unit test" }
    ];

    $scope.Tracking = { items: [] };

    $scope.addItem = function (index, date) {
        if (index != -1) {
            if ($scope.Tracking.items.length > 0) {
                date = $scope.Tracking.items[index].Date;
            }
            else {
                date = new Date().getMonday().formatDate("dd-MM-yyyy");
            }

            $scope.Tracking.items.splice(index + 1, 0, {
                Date: new Date(date),
                Name: [],
                Application: [],
                TaskType: [],
                Phase: [],
                Effort: 0,
                Sprint: '',
                UserStory: '',
                TaskDesc: ''
            });
        }
        else {
            if (date == null || date == undefined) {
                date = new Date().getMonday().formatDate("dd-MM-yyyy");
            }
            $scope.Tracking.items.push({
                Date: new Date(date),
                Name: [],
                Application: [],
                TaskType: [],
                Phase: [],
                Effort: 0,
                Sprint: '',
                UserStory: '',
                TaskDesc: ''
            });
        }

    },

    $scope.removeItem = function (index) {
        $scope.Tracking.items.splice(index, 1);
    },

    $scope.submit = function () {
        //Submit functionality
    },

    $scope.cancel = function () {
        //Cancel functionality
    }

    scope = $scope;
    loadDefautItemsForWeek();
});

function loadDefautItemsForWeek() {
    var startDt = new Date().getMonday();
    for (i = 0; i < 5; i++) {
        scope.addItem(-1, startDt.formatDate("dd-MM-yyyy"));
        startDt.addDays(1);
    }
}

Date.prototype.getMonday = function () {
    var day = this.getDay() || 7;
    if (day !== 1)
        this.setHours(-24 * (day - 1));
    return this;
}

Date.prototype.addDays = function (days) {
    this.setDate(this.getDate() + parseInt(days));
    return this;
};

Date.prototype.formatDate = function (format) {
    var date = this,
        day = date.getDate(),
        month = date.getMonth() + 1,
        year = date.getFullYear(),
        hours = date.getHours(),
        minutes = date.getMinutes(),
        seconds = date.getSeconds();

    if (!format) {
        format = "MM/dd/yyyy";
    }

    format = format.replace("MM", month.toString().replace(/^(\d)$/, '0$1'));

    if (format.indexOf("yyyy") > -1) {
        format = format.replace("yyyy", year.toString());
    } else if (format.indexOf("yy") > -1) {
        format = format.replace("yy", year.toString().substr(2, 2));
    }

    format = format.replace("dd", day.toString().replace(/^(\d)$/, '0$1'));

    if (format.indexOf("t") > -1) {
        if (hours > 11) {
            format = format.replace("t", "pm");
        } else {
            format = format.replace("t", "am");
        }
    }

    if (format.indexOf("HH") > -1) {
        format = format.replace("HH", hours.toString().replace(/^(\d)$/, '0$1'));
    }

    if (format.indexOf("hh") > -1) {
        if (hours > 12) {
            hours -= 12;
        }

        if (hours === 0) {
            hours = 12;
        }
        format = format.replace("hh", hours.toString().replace(/^(\d)$/, '0$1'));
    }

    if (format.indexOf("mm") > -1) {
        format = format.replace("mm", minutes.toString().replace(/^(\d)$/, '0$1'));
    }

    if (format.indexOf("ss") > -1) {
        format = format.replace("ss", seconds.toString().replace(/^(\d)$/, '0$1'));
    }

    return format;
};

mainApp.directive('ngConfirmClick', [
        function () {
            return {
                link: function (scope, element, attr) {
                    var msg = attr.ngConfirmClick || "Are you sure?";
                    var clickAction = attr.confirmedClick;
                    element.bind('click', function (event) {
                        if (window.confirm(msg)) {
                            scope.$eval(clickAction)
                        }
                    });
                }
            };
        }]);