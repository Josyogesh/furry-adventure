﻿mainApp.controller('contactController', function ($scope) {
    $scope.message = "This page will be used to display contactController";
});