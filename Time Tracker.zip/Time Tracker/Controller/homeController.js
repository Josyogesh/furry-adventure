﻿mainApp.controller('homeController', function ($scope) {
    $scope.message = "This page will be used to display homeController";
});