﻿/// <reference path="../Resources/Scripts/angular.min.js" />

var mainApp = angular.module("mainApp", ['ngRoute']);
mainApp.config(['$routeProvider', function ($routeProvider) {
    $routeProvider.
    //when('/', {
    //    templateUrl: 'Index.html',
    //    controller: 'mainController'
    //}).

    when('/home', {
        templateUrl: '../Partial Views/Home.html',
        controller: 'homeController'
    }).

    when('/tracker', {
        templateUrl: '../Partial Views/Tracker.html',
        controller: 'trackerController'
    }).

    when('/reports', {
        templateUrl: '../Partial Views/Reports.html',
        controller: 'reportController'
    }).

    when('/contacts', {
        templateUrl: '../Partial Views/Contacts.html',
        controller: 'contactController'
    }).

    otherwise({
        redirectTo: '/'
    });
}]);